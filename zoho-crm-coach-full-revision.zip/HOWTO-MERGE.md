# Merging the Zoho CRM Coach revisions into training-portal

This session isn't authorized to push directly to `OneAccord-Official/training-portal`,
so here's everything you need to get these changes live yourself. No git experience
required — the GitHub web UI can do all of it.

## What's in this package

Everything in this zip mirrors the exact folder structure of the repo, so each
file goes to the same-named path.

- `data/trainings-index.json` — updated nav manifest (Lesson 6 retitled, Lesson 7
  flipped from "pending" to "ready", "(Coming Soon)" dropped from its title)
- `data/trainings/zoho-crm-coach/lesson-1.json` through `lesson-8.json` — every
  lesson, fully revised: Account→Company, Inquiry→Lead, Opportunity→Buyer's Journey
  terminology throughout; the old 9-stage pipeline and BANTS/Managing-Principal
  gate removed; the B.U.Y.E.R.S. framework as the one active pipeline; Growth
  Loops references removed; inline screenshots added; Lesson 7 newly built
  ("Using AI Alongside Zoho" — Zia and Claude); Lesson 8 now closes out the course
- `data/trainings/zoho-crm-coach/images/` — all screenshots referenced by the
  lessons above, organized into `lesson-1/` through `lesson-8/` subfolders
- `css/styles.css` — adds the screenshot styling (`.block-text figure`, `figure img`,
  `figcaption`) used by the inline images

## One thing this package can't do: delete Lesson 9

Lesson 9 ("Master Social Media") has been retired completely. A zip can only add
or overwrite files, not delete them, so you'll need to manually remove these two
paths from the repo once the rest is merged in:

- `data/trainings/zoho-crm-coach/lesson-9.json`
- `data/trainings/zoho-crm-coach/images/lesson-9/` (the whole folder, if it exists)

## Steps (GitHub web UI)

1. Go to `https://github.com/OneAccord-Official/training-portal`
2. Navigate to `data/trainings/zoho-crm-coach/`, click **Add file → Upload files**,
   and drag in `lesson-1.json` through `lesson-8.json` from this package. GitHub
   will overwrite the existing files since the names match.
3. Still in that same upload screen (or a new one), drag in the whole `images`
   folder from this package — GitHub's upload supports dragging folders and will
   recreate the `lesson-1/` ... `lesson-8/` subfolder structure automatically.
4. Go to the repo root, open `data/trainings-index.json`, click the pencil
   (Edit this file), and replace its contents with the version from this package
   — or upload it the same drag-and-drop way as step 2.
5. Open `css/styles.css`, click the pencil, and replace its contents with the
   version from this package (or upload it the same way).
6. Delete `data/trainings/zoho-crm-coach/lesson-9.json`: open that file in
   GitHub, click the trash-can icon, and commit. If an `images/lesson-9/` folder
   exists, delete each file inside it the same way (GitHub removes the empty
   folder automatically once it's empty).
7. Commit all of the above directly to `main` (or open a PR first if you'd
   rather review the diff before it goes live).
8. Netlify auto-deploys from `main`. Give it a minute or two, then check
   `https://oneaccord-training-portal.netlify.app`, click through Lessons 1–8 in
   the nav, and confirm the screenshots render and Lesson 7 is no longer showing
   "Coming Soon."

## If you'd rather use git directly

If you have the repo cloned locally and are comfortable with git:

```bash
cd training-portal
git checkout -b zoho-crm-coach-revision
# copy the contents of this package's data/ and css/ folders over the matching
# folders in your local clone, overwriting existing files
git rm data/trainings/zoho-crm-coach/lesson-9.json
git rm -r data/trainings/zoho-crm-coach/images/lesson-9  # if it exists
git add -A
git commit -m "Revise Zoho CRM Coach: BUYERS pipeline, terminology, screenshots, Lesson 7"
git push -u origin zoho-crm-coach-revision
```

Then open a PR against `main` on GitHub, or merge directly if you're confident
in the changes.
